/* 
 * File:   sine_generator.h
 * Author: rafaelavelar
 *
 * Created on December 12, 2022, 1:58 PM
 */

#ifndef SINE_GENERATOR_H
#define	SINE_GENERATOR_H

#ifdef	__cplusplus
extern "C" {
#endif


    
//DAC mask bits sets the maximum voltage to 2.048V
#define SIGMASK 0x0FFF //0000 1111 1111 1111 
#define CONBITS 0x3000 //0011 0000 0000 0000 


void setup(void);
void setupTimer(void);
void setupSPI(void);
void setup_External_Interrupt(void);
void setupIC(void);
void __attribute__((interrupt (auto_psv))) _T3Interrupt(void);
void __attribute__((interrupt (auto_psv))) _SPI1Interrupt(void);
void __attribute__((interrupt (auto_psv))) _INT0Interrupt(void); 
void __attribute__((interrupt (auto_psv))) _IC1Interrupt(void);
void setFrequency(double); 
void setFrequencyArray(double, double);

    

#ifdef	__cplusplus
}
#endif

#endif	/* SINE_GENERATOR_H */

