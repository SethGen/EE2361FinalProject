#include <p24FJ64GA002.h>
#include "xc.h"
#include <math.h>
#include "ADC_module.h"
#include "st7735.h"





