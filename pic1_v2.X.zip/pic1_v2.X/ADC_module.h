/* 
 * File:   ADC_module.h
 * Author: rafaelavelar
 *
 * Created on December 14, 2022, 8:37 AM
 */

#ifndef ADC_MODULE_H
#define	ADC_MODULE_H

#ifdef	__cplusplus
extern "C" {
#endif

void setup_ADC(void); //Sets up ADC
void setup_External_Interrupt(void); //Sets up external interrupt to detect button presses
void __attribute__((__interrupt__,__auto_psv__)) _ADC1Interrupt(void); 
void __attribute__((__interrupt__,__auto_psv__)) _INT0Interrupt(void);
void __attribute__((__interrupt__,__auto_psv__)) _T2Interrupt(void);


#ifdef	__cplusplus
}
#endif

#endif	/* ADC_MODULE_H */

