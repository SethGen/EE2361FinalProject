/*
 * File:   pic2.c
 * Author: Rafael Avelar, Seth Gentry
 *
 * Created on December 2, 2022, 6:01 AM
 * 
 * 
 * This program controls the ADC module and the LCD interfacing for the frequency response analysis tool.
 * 
 * Our FRA tool works by having another PIC act as a function generator and create sine waves of
 * different frequencies. Sine waves are passed through an analog filter and their magnitude is
 * measured for each frequency. This program controls the rate of the frequency sweep and can reset
 * the frequency sweep by sending pulses to the other PIC. 
 * 
 *  The LCD display functions are included with the st7735 library. The functions setting up the ADC and 
 * the communication between both PICs in our FRA tool are defined in this file. We have setup functions
 * for the ADC, the timer and the external interrupt. 
 * 
 * At each frequency, the ADC measures the peak voltage. This point is plotted on the LCD screen and a pulse
 * is sent to the other PIC to update the frequency. The rate of the frequency sweep is determined by Timer 2.
 * This process is repeated across all frequencies defined in the sweep. We also have a button setup connected 
 * to the external interrupt to reset the sweep and plot a second graph.
 * 
 */

//Boilerplate Code
#include "xc.h" 
#include "colors.h"
#include "st7735.h" //LCD display library

// CW1: FLASH CONFIGURATION WORD 1 (see PIC24 Family Reference Manual 24.1)
#pragma config ICS = PGx1          // Comm Channel Select (Emulator EMUC1/EMUD1 pins are shared with PGC1/PGD1)
#pragma config FWDTEN = OFF        // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config GWRP = OFF          // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF           // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF        // JTAG Port Enable (JTAG port is disabled)


// CW2: FLASH CONFIGURATION WORD 2 (see PIC24 Family Reference Manual 24.1)
#pragma config I2C1SEL = PRI       // I2C1 Pin Location Select (Use default SCL1/SDA1 pins)
#pragma config IOL1WAY = OFF       // IOLOCK Protection (IOLOCK may be changed via unlocking seq)
#pragma config OSCIOFNC = ON       // Primary Oscillator I/O Function (CLKO/RC15 functions as I/O pin)
#pragma config FCKSM = CSECME      // Clock Switching and Monitor (Clock switching is enabled, 
                                       // Fail-Safe Clock Monitor is enabled)
#pragma config FNOSC = FRCPLL      // Oscillator Select (Fast RC Oscillator with PLL module (FRCPLL))
//End of Boilerplate Code

#define numColors 5 //Number of colors that will be used in plotting FRAs

volatile unsigned int ADCdata[plotSamples]; //Contains the data that will be plotted: the max ADC values for each frequency
volatile unsigned int i = 0; //Keeps track of current frequency we are at
volatile int max = 0;  //Keeps track of the peak ADC value
volatile int ADCBufVal = 0; //Keeps track of the current ADC value
volatile int count = 0; //Keeps track of how many graphs have been generated
volatile int colors[numColors]; //Contains the colors for different graphs

//The following functions are highly specific to our project and were not 
//made into a reusable library. 
void setup(void); //Sets up output pins and timer 2
void setup_ADC(void); //Sets up ADC
void setup_External_Interrupt(void); //Sets up external interrupt to detect button presses
void __attribute__((__interrupt__,__auto_psv__)) _ADC1Interrupt(void); 
void __attribute__((__interrupt__,__auto_psv__)) _INT0Interrupt(void);
void __attribute__((__interrupt__,__auto_psv__)) _T2Interrupt(void);
void setColors(void);




int main() {   
    
    setup();
    ST7735_initR(); //Initialize LCD
    ST7735_fillScreen(colBlack); //Draw a black background
    menu(); //Draw graph axes and labels
    initArray(ADCdata); //Initialize the array that will be plotted
    setup_External_Interrupt(); //Set up button press detection
    setColors(); //Set what colors will be used in the plot
    setup_ADC(); //Setup ADC
    draw3dbLine(); //Draw line corresponding to the cut off frequency
    
    _RB14 = 1; 
    delay_ms(10); 
    _RB14 = 0;    //Reset the function generator
    delay_ms(10); //Wait for everything to get ready
    
   
    while(1){}
    
}




void setup(void){
    CLKDIVbits.RCDIV = 0;  //Set RCDIV=1:1 (default 2:1) 32MHz or FCY/2=16MHz
    //Digital Port Initialization
    AD1PCFG = 0x9fff;
    TRISA = 0xffff;
    TRISB = 0x9fff;
    
    //LCD display communication pins
    TRISAbits.TRISA0 = 0;
    TRISAbits.TRISA1 = 0;
    TRISBbits.TRISB5 = 0;
    TRISBbits.TRISB6 = 0;
    TRISBbits.TRISB8 = 0;
    
    //Setup communication lines between PICs
    TRISBbits.TRISB15 = 0; //Communication line1: This will output the pulse to change frequencies
    TRISBbits.TRISB14 = 0; //Communication line2: This will reset the frequencies
    
    
    //Initialize timer to keep track of when the frequency should be updated
    T2CON = 0x0030; //PRE 1:256. Not turned on yet
    TMR2 = 0;     // Initialize to zero
    PR2 = (int)(0xFFFF * 0.75); //Interrupt every ~0.75 seconds
    
    _T2IF = 0;
    _T2IE = 1;
}

//Setup to ADC to measure the input voltage at pin AN12
void setup_ADC(void) {
    
    AD1PCFGbits.PCFG12 = 0; // AN12 is the only analog pin we are using

    // Setup on A/D
    AD1CON1 = 0;
    AD1CON2 = 0;
    AD1CON3 = 0;
    AD1CHS = 0;

    AD1CON1bits.ASAM = 1; // auto-sampling
    AD1CON1bits.SSRC = 0b111; // Internal counter
    
    AD1CON3bits.SAMC = 12; // auto-sample time (333KHZ Sampling frequency)
    AD1CON3bits.ADCS = 1; // Tad = 2*Tcy 
    AD1CHSbits.CH0SA = 0b01100; //Choose AN12 as the input source
    
    // Configure A/D interrupt
    _AD1IF = 0; // clear flag
    _AD1IE = 1; // enable interrupt

    AD1CON1bits.ADON = 1;
}

//External interrupt is used to determine when a button was pressed
void setup_External_Interrupt(){
    INTCON2bits.INT0EP = 1; //Capture falling edge
    IFS0bits.INT0IF = 0;
    IPC0bits.INT0IP = 6;
    IEC0bits.INT0IE = 1;
    CNPU2bits.CN23PUE = 1; //Pull-up resistor
}


//This ISR updates the current peak voltage we are measuring for a particular frequency.
//When conversion ends, we retrieve the value from the ADC buffer and determine whether or not
//we should update the current maximum value. If the input is greater that the current maximum value,
//the variable max is updated. Otherwise, the ADC1BUF value is discarded.
void _ISR _ADC1Interrupt(void){

    IFS0bits.AD1IF = 0;
    ADCBufVal = ADC1BUF0; 
    
    //We only care about the maximum value
     if (ADCBufVal >= max) {
         max = ADCBufVal;
     }
}


//This ISR is entered when a button is pressed. The button press is a signal to 
//reset the frequency sweep and start creating a new plot. Thus, the max voltage 
//is reset and the timer is turned on. A pulse is sent to the other PIC to reset the frequency sweep.
void _ISR _INT0Interrupt(void) {
    
    _INT0IF = 0;
    
    TMR2 = 0; //Reset timer
    T2CONbits.TON = 1; //Restart timer
    i = 0; //Reset index
    max = 0; //Reset max voltage
    ADCBufVal = 0; //Reset ADC retrieval variable
    
    _RB14 = 1; 
    delay_ms(10); 
    _RB14 = 0;    //Send a low pulse to reset the function generator module
    delay_ms(10); //Wait for everything to get ready
}



//Timer 2 interrupt controls when the frequency should be updated. Every timer period, this
//ISR plots the current measured peak voltage and sends a signal to the function generator module
//to move on to the next frequency
void _ISR _T2Interrupt(void)
{ 
    _T2IF = 0;

    ADCdata[i] = max; //Get current max value (ADCdata array is currently not used)
    i++;
    
    unsigned int max_dBV = makeDBV_single(max); //Make dBV
    
    ST7735_fillRect(max_dBV + 7 , 8 + ((150/plotSamples)*i),3,(150/plotSamples),colors[count]);//plot single (line)
    
    if(i >= plotSamples){
        T2CONbits.TON = 0; //If we have done all frequencies, stop the clock
        TMR2 = 0; //Reset timer
        count++; //Keep track on how many iterations we have done
        count %= numColors; //numColors is the size of the colors array. If we exceed that, go back to the 
                            //first color.
    }
    
    //Output a low pulse to go on to the next frequency. If we are at the last frequency, we return
    // to the first one and get ready for the next sweep.
    _RB15 = 0; 
    delay_ms(1);
    _RB15 = 1;
    max=0; //Reset the max value
}

//Define the colors that might be used in the plot
void setColors(void){
    colors[0] = colLightSkyBlue;
    colors[1] = colYellow;
    colors[2] = colGreen;
    colors[3] = colMistyRose;
    colors[4] = colYellow;
}

